# -*- coding: utf-8 -*-
"""
app.py — Gradio demo for the AC Fault-Detection RandomForest model.

Deploy this on a Hugging Face Space (SDK: gradio).
It loads `best_model.pkl` (produced by CoevolutionLoop.py) and builds
an input form automatically from `model.feature_names_in_`, so you
don't need to hardcode feature names/order.

Required files in the Space repo:
    app.py              (this file)
    requirements.txt
    best_model.pkl      (your trained model — upload it to the Space)
"""

import joblib
import numpy as np
import gradio as gr

MODEL_PATH = "best_model.pkl"

# --- Load model once at startup ---
model = joblib.load(MODEL_PATH)
FEATURES = list(model.feature_names_in_)
CLASSES = [str(c) for c in model.classes_]

print(f"[app] Loaded model with {len(FEATURES)} features and classes: {CLASSES}")


def predict(*values):
    """Takes feature values in FEATURES order, returns class + probabilities."""
    X = np.array(values, dtype=float).reshape(1, -1)
    pred = model.predict(X)[0]
    proba = model.predict_proba(X)[0]
    prob_dict = {cls: float(p) for cls, p in zip(CLASSES, proba)}
    return str(pred), prob_dict


# --- Build the UI dynamically from the model's expected features ---
with gr.Blocks(title="AC Fault Detection") as demo:
    gr.Markdown(
        "# AC Unit Fault Detection\n"
        "Enter the sensor readings below and click **Predict** to classify "
        "the operating condition (NORMAL / MAINTENANCE / TROUBLE, etc.)."
    )

    with gr.Row():
        with gr.Column():
            inputs = [gr.Number(label=feat, value=0.0) for feat in FEATURES]
            predict_btn = gr.Button("Predict", variant="primary")
        with gr.Column():
            label_out = gr.Textbox(label="Predicted Condition")
            proba_out = gr.Label(label="Class Probabilities", num_top_classes=len(CLASSES))

    predict_btn.click(fn=predict, inputs=inputs, outputs=[label_out, proba_out])

    gr.Markdown(
        "*Model expects {} numeric features (auto-detected from the saved "
        "model's `feature_names_in_`).*".format(len(FEATURES))
    )

if __name__ == "__main__":
    demo.launch()
